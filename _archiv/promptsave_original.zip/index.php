<?php
/**
 * realteacher's promptsave - Single File PHP App
 * Version 2.0
 * 
 * Eine komplette Prompt-Manager-App mit SQLite-Datenbank
 * Alles in einer einzigen index.php Datei
 */

// ===== DATABASE SETUP =====
$dbFile = __DIR__ . '/prompts.db';
$db = null;

// SQLite Datenbank initialisieren
try {
    $db = new PDO('sqlite:' . $dbFile);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Tabelle erstellen, falls nicht vorhanden
    $db->exec("CREATE TABLE IF NOT EXISTS prompts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        category TEXT NOT NULL CHECK(category IN ('gemini', 'chatgpt', 'general')),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        created_timestamp INTEGER NOT NULL,
        updated_timestamp INTEGER NOT NULL
    )");
} catch (PDOException $e) {
    die("Datenbankfehler: " . $e->getMessage());
}

// ===== API ENDPOINTS =====
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = preg_replace('/^.*\//', '', $path); // Get last part of path

// API-Anfrage erkennen
if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
    header('Content-Type: application/json; charset=utf-8');
    handleAPI($db, $method, $path);
    exit;
}

// ===== API HANDLER =====
function handleAPI($db, $method, $path) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($method) {
        case 'GET':
            if ($path === 'prompts') {
                getPrompts($db);
            } elseif (strpos($path, 'prompts/') === 0) {
                $id = substr($path, 8);
                getPrompt($db, $id);
            } elseif ($path === 'stats') {
                getStats($db);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Endpoint nicht gefunden']);
            }
            break;
            
        case 'POST':
            if ($path === 'prompts') {
                createPrompt($db, $input);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Endpoint nicht gefunden']);
            }
            break;
            
        case 'PUT':
            if (strpos($path, 'prompts/') === 0) {
                $id = substr($path, 8);
                updatePrompt($db, $id, $input);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Endpoint nicht gefunden']);
            }
            break;
            
        case 'DELETE':
            if (strpos($path, 'prompts/') === 0) {
                $id = substr($path, 8);
                deletePrompt($db, $id);
            } elseif ($path === 'prompts') {
                deleteAllPrompts($db);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Endpoint nicht gefunden']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Methode nicht erlaubt']);
    }
}

// GET alle Prompts
function getPrompts($db) {
    try {
        $stmt = $db->prepare("
            SELECT uuid, title, content, category, created_at, updated_at 
            FROM prompts 
            ORDER BY created_timestamp DESC
        ");
        $stmt->execute();
        $prompts = [];
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $prompts[] = [
                'id' => $row['uuid'],
                'title' => $row['title'],
                'content' => $row['content'],
                'category' => $row['category'],
                'createdAt' => $row['created_at'],
                'updatedAt' => $row['updated_at']
            ];
        }
        
        echo json_encode($prompts);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Abrufen der Prompts']);
    }
}

// GET einzelner Prompt
function getPrompt($db, $id) {
    try {
        $stmt = $db->prepare("
            SELECT uuid, title, content, category, created_at, updated_at 
            FROM prompts 
            WHERE uuid = ?
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Prompt nicht gefunden']);
            return;
        }
        
        echo json_encode([
            'id' => $row['uuid'],
            'title' => $row['title'],
            'content' => $row['content'],
            'category' => $row['category'],
            'createdAt' => $row['created_at'],
            'updatedAt' => $row['updated_at']
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Abrufen des Prompts']);
    }
}

// CREATE Prompt
function createPrompt($db, $input) {
    $title = $input['title'] ?? '';
    $content = $input['content'] ?? '';
    $category = $input['category'] ?? '';
    
    // Validierung
    if (empty($title) || empty($content) || empty($category)) {
        http_response_code(400);
        echo json_encode(['error' => 'Titel, Inhalt und Kategorie sind erforderlich']);
        return;
    }
    
    if (!in_array($category, ['gemini', 'chatgpt', 'general'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Ungültige Kategorie']);
        return;
    }
    
    if (strlen($content) > 10000) {
        http_response_code(400);
        echo json_encode(['error' => 'Prompt darf max. 10.000 Zeichen lang sein']);
        return;
    }
    
    try {
        $uuid = time() . '-' . substr(md5(microtime(true)), 0, 9);
        $now = date('d.m.Y H:i:s');
        $timestamp = time() * 1000;
        
        $stmt = $db->prepare("
            INSERT INTO prompts (uuid, title, content, category, created_at, updated_at, created_timestamp, updated_timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$uuid, $title, $content, $category, $now, $now, $timestamp, $timestamp]);
        
        http_response_code(201);
        echo json_encode([
            'id' => $uuid,
            'title' => $title,
            'content' => $content,
            'category' => $category,
            'createdAt' => $now,
            'updatedAt' => $now
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Speichern des Prompts']);
    }
}

// UPDATE Prompt
function updatePrompt($db, $id, $input) {
    $title = $input['title'] ?? '';
    $content = $input['content'] ?? '';
    $category = $input['category'] ?? '';
    
    // Validierung
    if (empty($title) || empty($content) || empty($category)) {
        http_response_code(400);
        echo json_encode(['error' => 'Titel, Inhalt und Kategorie sind erforderlich']);
        return;
    }
    
    if (!in_array($category, ['gemini', 'chatgpt', 'general'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Ungültige Kategorie']);
        return;
    }
    
    try {
        $now = date('d.m.Y H:i:s');
        $timestamp = time() * 1000;
        
        $stmt = $db->prepare("
            UPDATE prompts 
            SET title = ?, content = ?, category = ?, updated_at = ?, updated_timestamp = ?
            WHERE uuid = ?
        ");
        
        $stmt->execute([$title, $content, $category, $now, $timestamp, $id]);
        
        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Prompt nicht gefunden']);
            return;
        }
        
        echo json_encode([
            'id' => $id,
            'title' => $title,
            'content' => $content,
            'category' => $category,
            'updatedAt' => $now
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Aktualisieren des Prompts']);
    }
}

// DELETE Prompt
function deletePrompt($db, $id) {
    try {
        $stmt = $db->prepare("DELETE FROM prompts WHERE uuid = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Prompt nicht gefunden']);
            return;
        }
        
        echo json_encode(['message' => 'Prompt erfolgreich gelöscht']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Löschen des Prompts']);
    }
}

// DELETE alle Prompts
function deleteAllPrompts($db) {
    try {
        $stmt = $db->prepare("DELETE FROM prompts");
        $stmt->execute();
        
        echo json_encode(['message' => 'Alle Prompts gelöscht']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Löschen aller Prompts']);
    }
}

// GET Statistiken
function getStats($db) {
    try {
        $stmt = $db->prepare("
            SELECT category, COUNT(*) as count 
            FROM prompts 
            GROUP BY category
        ");
        $stmt->execute();
        
        $stats = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $stats[] = $row;
        }
        
        echo json_encode($stats);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Fehler beim Abrufen der Statistiken']);
    }
}

?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>realteacher's promptsave. - Prompt Manager</title>
    <link rel="icon" type="image/png" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect fill='%231DB679' width='100' height='100'/><text x='50' y='65' font-size='60' font-weight='bold' text-anchor='middle' fill='white'>P</text></svg>">
    <style>
        :root {
            --primary: #1DB679;
            --primary-light: #26D18C;
            --primary-dark: #16995A;
            --surface: #F5F5F5;
            --surface-variant: #FFFFFF;
            --on-surface: #1C1B1F;
            --on-surface-variant: #49454E;
            --outline: #D4C7D0;
            --error: #F32424;
            --success: #4CAF50;
            --warning: #FF9800;
            --info: #2196F3;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: var(--surface);
            color: var(--on-surface);
            line-height: 1.6;
        }

        .container {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 280px;
            background: var(--surface-variant);
            border-right: 1px solid var(--outline);
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 8px rgba(0,0,0,0.08);
        }

        .sidebar-header {
            padding: 24px 16px;
            border-bottom: 1px solid var(--outline);
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .sidebar-header::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 180px;
            height: 180px;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            z-index: 0;
            pointer-events: none;
        }

        .sidebar-header h1,
        .sidebar-header p,
        .sidebar-header > div {
            position: relative;
            z-index: 1;
        }

        .sidebar-header h1 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .sidebar-header p {
            font-size: 12px;
            opacity: 0.9;
        }

        .nav-section {
            padding: 16px 8px;
        }

        .nav-section-title {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--on-surface-variant);
            padding: 8px 16px;
            margin-top: 8px;
        }

        .nav-item {
            padding: 12px 16px;
            margin: 4px 8px;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.2s ease;
            border: 2px solid transparent;
        }

        .nav-item:hover {
            background: rgba(29, 182, 121, 0.08);
        }

        .nav-item.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary-dark);
            font-weight: 600;
        }

        .nav-item span {
            font-size: 20px;
        }

        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .header {
            background: var(--surface-variant);
            border-bottom: 1px solid var(--outline);
            padding: 20px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .header h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .content {
            flex: 1;
            overflow-y: auto;
            padding: 32px;
            position: relative;
        }

        .content > * {
            position: relative;
            z-index: 1;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--on-surface);
            text-transform: uppercase;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--outline);
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            transition: all 0.2s ease;
            background: var(--surface-variant);
            color: var(--on-surface);
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(29, 182, 121, 0.12);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 220px;
            font-family: 'Monaco', 'Menlo', 'Courier New', monospace;
            font-size: 13px;
        }

        .char-count {
            display: inline-block;
            margin-top: 6px;
            font-size: 12px;
            color: var(--on-surface-variant);
        }

        .char-count.warning {
            color: var(--warning);
        }

        .char-count.error {
            color: var(--error);
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-light);
            box-shadow: 0 4px 12px rgba(29, 182, 121, 0.3);
            transform: translateY(-2px);
        }

        .btn-primary:active {
            background: var(--primary-dark);
            transform: translateY(0);
        }

        .btn-secondary {
            background: transparent;
            color: var(--primary);
            border: 2px solid var(--primary);
        }

        .btn-secondary:hover {
            background: rgba(29, 182, 121, 0.08);
        }

        .btn-danger {
            background: var(--error);
            color: white;
        }

        .btn-danger:hover {
            background: #E31B0C;
            box-shadow: 0 4px 12px rgba(243, 36, 36, 0.3);
        }

        .btn-sm {
            padding: 8px 12px;
            font-size: 14px;
            min-width: 44px;
            justify-content: center;
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .card {
            background: var(--surface-variant);
            border: 1px solid var(--outline);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--on-surface);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .category-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 16px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            margin-top: 8px;
        }

        .category-gemini {
            background: rgba(0, 188, 212, 0.15);
            color: #0096AA;
        }

        .category-chatgpt {
            background: rgba(76, 175, 80, 0.15);
            color: #2E7D32;
        }

        .category-general {
            background: rgba(255, 152, 0, 0.15);
            color: #E65100;
        }

        .card-content {
            font-size: 13px;
            color: var(--on-surface-variant);
            line-height: 1.6;
            word-break: break-word;
            white-space: pre-wrap;
            background: rgba(0,0,0,0.02);
            padding: 12px;
            border-radius: 6px;
            margin: 12px 0;
            max-height: 200px;
            overflow: hidden;
            position: relative;
        }

        .card-content.expanded {
            max-height: none;
        }

        .card-content::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 40px;
            background: linear-gradient(transparent, var(--surface-variant));
            pointer-events: none;
        }

        .card-content.expanded::after {
            display: none;
        }

        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            padding-top: 12px;
            border-top: 1px solid var(--outline);
            font-size: 12px;
            color: var(--on-surface-variant);
            gap: 12px;
        }

        .card-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--on-surface-variant);
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 8px;
            color: var(--on-surface);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .nav-item {
                justify-content: center;
                padding: 12px;
            }

            .nav-item span:last-child {
                display: none;
            }

            .header {
                padding: 16px;
            }

            .content {
                padding: 16px;
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card {
            animation: slideIn 0.3s ease;
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: transparent;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--outline);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--on-surface-variant);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 12px;">
                    <img src="logo.png" alt="promptsave Logo" style="width: 128px; height: 128px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                </div>
                <h1 style="font-size: 18px; line-height: 1.2;">realteacher's<br>promptsave.</h1>
                <p style="font-size: 10px; margin-top: 4px; opacity: 0.85;">Prompt Manager v2.0 (PHP)</p>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Kategorien</div>
                <div class="nav-item active" onclick="filterByCategory('all')">
                    <span>📋</span>
                    <span>Alle Prompts</span>
                </div>
                <div class="nav-item" onclick="filterByCategory('gemini')">
                    <span>✨</span>
                    <span>Gemini</span>
                </div>
                <div class="nav-item" onclick="filterByCategory('chatgpt')">
                    <span>🤖</span>
                    <span>ChatGPT</span>
                </div>
                <div class="nav-item" onclick="filterByCategory('general')">
                    <span>🎯</span>
                    <span>Allgemein</span>
                </div>
            </div>

            <div class="nav-section" style="margin-top: auto; border-top: 1px solid var(--outline);">
                <div class="nav-section-title">Aktionen</div>
                <div class="nav-item" onclick="switchTab('create')">
                    <span>➕</span>
                    <span>Neuer Prompt</span>
                </div>
                <div class="nav-item" onclick="switchTab('import')">
                    <span>📥</span>
                    <span>Importieren</span>
                </div>
                <div class="nav-item" onclick="exportAsCSV()">
                    <span>📤</span>
                    <span>Exportieren</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2 id="headerTitle">Alle Prompts</h2>
                <div style="display: flex; gap: 12px; align-items: center;">
                    <input type="text" id="searchInput" placeholder="Prompts durchsuchen..." 
                        style="padding: 10px 16px; border: 2px solid var(--outline); border-radius: 8px; width: 300px;">
                    <span id="promptCount" style="font-weight: 600; color: var(--primary);">0 Prompts</span>
                </div>
            </div>

            <div class="content">
                <!-- Tab Content: View Prompts -->
                <div id="viewTab" class="tab-content active">
                    <div id="promptsList" style="display: grid; gap: 16px;"></div>
                </div>

                <!-- Tab Content: Import/Export Prompts -->
                <div id="importTab" class="tab-content" style="max-width: 600px;">
                    <h3 style="margin-bottom: 24px; font-size: 20px; display: flex; align-items: center; gap: 8px;">
                        <div style="width: 24px; height: 24px; background: linear-gradient(135deg, #26D18C 0%, #1DB679 100%); border-radius: 4px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 14px;">P</div>
                        <span>📥📤 Import & Export</span>
                    </h3>

                    <!-- Export Section -->
                    <div style="margin-bottom: 32px; padding: 20px; background: rgba(38, 209, 140, 0.05); border-radius: 12px; border: 1px solid rgba(29, 182, 121, 0.2);">
                        <h4 style="margin-bottom: 16px; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span>📤 Prompts exportieren</span>
                        </h4>
                        <p style="font-size: 12px; color: var(--on-surface-variant); margin-bottom: 16px;">
                            Lade deine aktuellen Prompts als CSV-Datei herunter. So kannst du sie sichern oder in anderen Tools verwenden.
                        </p>
                        <div style="display: flex; gap: 12px;">
                            <button type="button" class="btn btn-primary" style="flex: 1;" onclick="exportAsCSV()">
                                📊 Als CSV
                            </button>
                            <button type="button" class="btn btn-primary" style="flex: 1;" onclick="exportAsPDF()">
                                📄 Als PDF
                            </button>
                        </div>
                        <div style="font-size: 11px; color: var(--on-surface-variant); margin-top: 12px;">
                            <strong>Aktuelle Anzahl:</strong> <span id="exportCount">0</span> Prompts verfügbar
                        </div>
                    </div>

                    <!-- Import Section -->
                    <div style="padding: 20px; background: rgba(0, 188, 212, 0.05); border-radius: 12px; border: 1px solid rgba(0, 188, 212, 0.2);">
                        <h4 style="margin-bottom: 16px; font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span>📥 Prompts importieren</span>
                        </h4>
                        
                        <div class="form-group" style="margin-bottom: 16px;">
                            <label>CSV-Datei hochladen</label>
                            <div style="border: 2px dashed var(--outline); border-radius: 8px; padding: 32px; text-align: center; cursor: pointer; transition: all 0.2s ease;" id="dropZone">
                                <div style="font-size: 32px; margin-bottom: 12px;">📄</div>
                                <div style="font-weight: 600; margin-bottom: 4px;">Datei hierher ziehen</div>
                                <div style="font-size: 12px; color: var(--on-surface-variant); margin-bottom: 12px;">oder klicken zum auswählen</div>
                                <input type="file" id="csvFile" accept=".csv" style="display: none;">
                            </div>
                            <div style="font-size: 11px; color: var(--on-surface-variant); margin-top: 12px; line-height: 1.6;">
                                <strong>CSV-Format:</strong> title,content,category<br>
                                <strong>Kategorien:</strong> gemini, chatgpt, general<br>
                                <strong>Limit:</strong> Max. 10.000 Zeichen pro Prompt
                            </div>
                        </div>

                        <div id="importPreview" style="display: none;">
                            <div style="margin-bottom: 24px;">
                                <h4 style="margin-bottom: 16px; font-size: 14px; font-weight: 600;">📋 Vorschau (bis zu 5 Prompts)</h4>
                                <div id="previewList" style="display: grid; gap: 12px; margin-bottom: 16px;"></div>
                                <div style="padding: 12px; background: rgba(255, 152, 0, 0.1); border-radius: 6px; color: #E65100; font-size: 12px;">
                                    ⚠️ <span id="importCount">0</span> Prompts werden importiert
                                </div>
                            </div>
                            <div style="display: flex; gap: 12px;">
                                <button type="button" class="btn btn-primary" style="flex: 1;" onclick="importPrompts()">
                                    ✅ Importieren
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="cancelImport()">
                                    ❌ Abbrechen
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Content: Create/Edit Prompt -->
                <div id="createTab" class="tab-content" style="max-width: 600px;">
                    <h3 style="margin-bottom: 24px; font-size: 20px; display: flex; align-items: center; gap: 8px;">
                        <div style="width: 24px; height: 24px; background: linear-gradient(135deg, #26D18C 0%, #1DB679 100%); border-radius: 4px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 14px;">P</div>
                        <span id="formTitle">Neuen Prompt erstellen</span>
                    </h3>
                    
                    <form id="promptForm" onsubmit="savePrompt(event)">
                        <div class="form-group">
                            <label for="promptTitle">Prompt Titel</label>
                            <input type="text" id="promptTitle" placeholder="z.B. 'KI Bildung Erklärung'" required maxlength="100">
                        </div>

                        <div class="form-group">
                            <label for="promptContent">Prompt Text (max. 10.000 Zeichen)</label>
                            <textarea id="promptContent" placeholder="Gib deinen Prompt ein..." required maxlength="10000"></textarea>
                            <span class="char-count"><span id="charCount">0</span>/10.000</span>
                        </div>

                        <div class="form-group">
                            <label for="promptCategory">Kategorie</label>
                            <select id="promptCategory" required>
                                <option value="">-- Kategorie wählen --</option>
                                <option value="gemini">✨ Gemini</option>
                                <option value="chatgpt">🤖 ChatGPT</option>
                                <option value="general">🎯 Allgemein</option>
                            </select>
                        </div>

                        <div style="display: flex; gap: 12px; margin-top: 28px;">
                            <button type="submit" class="btn btn-primary" style="flex: 1;">
                                <span id="submitBtnText">💾 Prompt speichern</span>
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="resetForm()">
                                🔄 Zurücksetzen
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // ===== FRONTEND APP =====
        let allPrompts = [];
        let currentFilter = 'all';
        let editingId = null;

        // API Base URL
        const API_BASE = window.location.pathname.replace('index.php', '');

        // Initialize App
        async function initializeApp() {
            await loadPrompts();
            displayPrompts();
            setupEventListeners();
        }

        // ===== API CALLS =====
        async function loadPrompts() {
            try {
                const response = await fetch(API_BASE + 'api/prompts');
                if (response.ok) {
                    allPrompts = await response.json();
                } else {
                    showNotification('❌ Fehler beim Laden der Prompts');
                }
            } catch (error) {
                console.error('Fehler beim Laden:', error);
                showNotification('❌ Verbindungsfehler');
            }
        }

        async function savePrompt(event) {
            event.preventDefault();

            const title = document.getElementById('promptTitle').value.trim();
            const content = document.getElementById('promptContent').value.trim();
            const category = document.getElementById('promptCategory').value;

            if (!title || !content || !category) {
                alert('⚠️ Bitte alle Felder ausfüllen!');
                return;
            }

            try {
                if (editingId) {
                    // UPDATE
                    const response = await fetch(API_BASE + 'api/prompts/' + editingId, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ title, content, category })
                    });

                    if (response.ok) {
                        showNotification('✏️ Prompt aktualisiert!');
                        await loadPrompts();
                        resetForm();
                        displayPrompts();
                    } else {
                        const errorData = await response.json();
                        console.error('Update Error:', errorData);
                        showNotification('❌ ' + (errorData.error || 'Fehler beim Aktualisieren'));
                    }
                } else {
                    // CREATE
                    const response = await fetch(API_BASE + 'api/prompts', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ title, content, category })
                    });

                    if (response.ok) {
                        showNotification('✅ Prompt erstellt!');
                        await loadPrompts();
                        resetForm();
                        displayPrompts();
                    } else {
                        const errorData = await response.json();
                        console.error('Create Error:', errorData);
                        showNotification('❌ ' + (errorData.error || 'Fehler beim Erstellen'));
                    }
                }
            } catch (error) {
                console.error('Fehler:', error);
                showNotification('❌ Fehler bei der Operation');
            }
        }

        async function editPrompt(id) {
            const prompt = allPrompts.find(p => p.id === id);
            if (!prompt) return;

            editingId = id;
            document.getElementById('promptTitle').value = prompt.title;
            document.getElementById('promptContent').value = prompt.content;
            document.getElementById('promptCategory').value = prompt.category;
            document.getElementById('charCount').textContent = prompt.content.length;
            document.getElementById('formTitle').textContent = '✏️ Prompt bearbeiten';
            document.getElementById('submitBtnText').textContent = '💾 Änderungen speichern';

            switchTab('create');
            setTimeout(() => document.getElementById('promptTitle').focus(), 100);
        }

        async function deletePrompt(id) {
            if (confirm('🗑️ Diesen Prompt wirklich löschen?')) {
                try {
                    const response = await fetch(API_BASE + 'api/prompts/' + id, { method: 'DELETE' });
                    
                    if (response.ok) {
                        await loadPrompts();
                        displayPrompts();
                        showNotification('❌ Prompt gelöscht');
                    } else {
                        showNotification('❌ Fehler beim Löschen');
                    }
                } catch (error) {
                    console.error('Fehler:', error);
                    showNotification('❌ Fehler bei der Operation');
                }
            }
        }

        function copyToClipboard(content) {
            navigator.clipboard.writeText(content).then(() => {
                showNotification('📋 In Zwischenablage kopiert!');
            }).catch(err => {
                console.error('Fehler:', err);
                alert('❌ Kopieren fehlgeschlagen');
            });
        }

        // ===== DISPLAY & FILTERING =====
        function parsePromptDate(dateStr) {
            // Versuche verschiedene Dateiformate zu parsen
            if (!dateStr) return 'Unbekanntes Datum';
            
            // Format: "d.m.Y H:i:s" (PHP Format)
            const parts = dateStr.match(/(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})/);
            if (parts) {
                const [, day, month, year, hour, min, sec] = parts;
                return `${day}.${month}.${year}`;
            }
            
            // Fallback
            return dateStr;
        }

        function displayPrompts() {
            const listContainer = document.getElementById('promptsList');
            
            let filtered = allPrompts;
            if (currentFilter !== 'all') {
                filtered = allPrompts.filter(p => p.category === currentFilter);
            }

            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            if (searchTerm) {
                filtered = filtered.filter(p => 
                    p.title.toLowerCase().includes(searchTerm) || 
                    p.content.toLowerCase().includes(searchTerm)
                );
            }

            const headerTitles = {
                'all': '📋 Alle Prompts',
                'gemini': '✨ Gemini Prompts',
                'chatgpt': '🤖 ChatGPT Prompts',
                'general': '🎯 Allgemeine Prompts'
            };
            document.getElementById('headerTitle').textContent = headerTitles[currentFilter];
            document.getElementById('promptCount').textContent = `${filtered.length} ${filtered.length === 1 ? 'Prompt' : 'Prompts'}`;

            if (filtered.length === 0) {
                listContainer.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📭</div>
                        <h3>Keine Prompts gefunden</h3>
                        <p>Erstelle deinen ersten Prompt oder ändere deine Filter.</p>
                    </div>
                `;
                return;
            }

            listContainer.innerHTML = filtered.map(prompt => {
                const dateStr = parsePromptDate(prompt.createdAt);
                return `
                <div class="card">
                    <div class="card-header">
                        <div>
                            <div class="card-title">
                                ${getCategoryEmoji(prompt.category)} ${escapeHtml(prompt.title)}
                            </div>
                            <span class="category-badge category-${prompt.category}">
                                ${prompt.category}
                            </span>
                        </div>
                    </div>
                    <div class="card-content" id="content-${prompt.id}">
                        ${escapeHtml(prompt.content)}
                    </div>
                    <div class="card-footer">
                        <span>📅 ${dateStr}</span>
                        <div class="card-actions">
                            <button class="btn btn-sm btn-secondary" title="Kopieren" onclick="copyToClipboard('${prompt.content.replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, '\\n')}')">
                                📋
                            </button>
                            <button class="btn btn-sm btn-secondary" title="Mehr anzeigen" onclick="toggleContent('${prompt.id}')">
                                👁️
                            </button>
                            <button class="btn btn-sm btn-secondary" title="Bearbeiten" onclick="editPrompt('${prompt.id}')">
                                ✏️
                            </button>
                            <button class="btn btn-sm btn-danger" title="Löschen" onclick="deletePrompt('${prompt.id}')">
                                🗑️
                            </button>
                        </div>
                    </div>
                </div>
            `;
            }).join('');
        }

        function toggleContent(id) {
            const element = document.getElementById(`content-${id}`);
            if (element) element.classList.toggle('expanded');
        }

        function filterByCategory(category) {
            currentFilter = category;
            document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
            event.target.closest('.nav-item').classList.add('active');
            displayPrompts();
        }

        function switchTab(tab) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            if (tab === 'create') {
                document.getElementById('createTab').classList.add('active');
                document.getElementById('promptTitle').focus();
            } else if (tab === 'import') {
                document.getElementById('importTab').classList.add('active');
            } else {
                document.getElementById('viewTab').classList.add('active');
            }
        }

        function resetForm() {
            editingId = null;
            document.getElementById('promptForm').reset();
            document.getElementById('charCount').textContent = '0';
            document.getElementById('formTitle').textContent = 'Neuen Prompt erstellen';
            document.getElementById('submitBtnText').textContent = '💾 Prompt speichern';
            switchTab('view');
        }

        // ===== UTILITIES =====
        function getCategoryEmoji(category) {
            const emojis = { 'gemini': '✨', 'chatgpt': '🤖', 'general': '🎯' };
            return emojis[category] || '📝';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function showNotification(message) {
            const notification = document.createElement('div');
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: var(--primary);
                color: white;
                padding: 16px 24px;
                border-radius: 8px;
                z-index: 999;
                animation: slideIn 0.3s ease;
            `;
            document.body.appendChild(notification);
            setTimeout(() => notification.remove(), 3000);
        }

        function updateExportCount() {
            document.getElementById('exportCount').textContent = allPrompts.length;
        }

        // ===== IMPORT/EXPORT FUNCTIONS =====
        let pendingImport = [];

        function setupEventListeners() {
            document.getElementById('promptContent').addEventListener('input', (e) => {
                const count = e.target.value.length;
                const countEl = document.getElementById('charCount');
                countEl.textContent = count;
                countEl.parentElement.className = 'char-count';
                if (count > 9000) countEl.parentElement.classList.add('warning');
                if (count >= 10000) countEl.parentElement.classList.add('error');
            });

            document.getElementById('searchInput').addEventListener('input', displayPrompts);

            // Import Drop Zone
            const dropZone = document.getElementById('dropZone');
            const csvFile = document.getElementById('csvFile');

            dropZone.addEventListener('click', () => csvFile.click());
            csvFile.addEventListener('change', handleFileSelect);

            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.style.background = 'rgba(29, 182, 121, 0.1)';
                dropZone.style.borderColor = 'var(--primary)';
            });

            dropZone.addEventListener('dragleave', () => {
                dropZone.style.background = 'transparent';
                dropZone.style.borderColor = 'var(--outline)';
            });

            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                dropZone.style.background = 'transparent';
                dropZone.style.borderColor = 'var(--outline)';
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    csvFile.files = files;
                    handleFileSelect({ target: { files } });
                }
            });
        }

        // CSV Parser für korrekte Behandlung von Kommas in Feldern
        function parseCSVLine(line) {
            const result = [];
            let current = '';
            let insideQuotes = false;

            for (let i = 0; i < line.length; i++) {
                const char = line[i];
                const nextChar = line[i + 1];

                if (char === '"') {
                    if (insideQuotes && nextChar === '"') {
                        current += '"';
                        i++;
                    } else {
                        insideQuotes = !insideQuotes;
                    }
                } else if (char === ',' && !insideQuotes) {
                    result.push(current.trim());
                    current = '';
                } else {
                    current += char;
                }
            }

            result.push(current.trim());
            return result;
        }

        function handleFileSelect(event) {
            const file = event.target.files[0];
            if (!file) return;

            if (!file.name.endsWith('.csv')) {
                showNotification('❌ Bitte eine CSV-Datei wählen');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const csv = e.target.result;
                    const lines = csv.trim().split('\n');
                    
                    if (lines.length < 2) {
                        showNotification('❌ CSV-Datei ist leer');
                        return;
                    }

                    // Header mit korrektem CSV-Parser lesen
                    const header = parseCSVLine(lines[0]).map(h => h.toLowerCase());
                    const titleIdx = header.indexOf('title');
                    const contentIdx = header.indexOf('content');
                    const categoryIdx = header.indexOf('category');

                    if (titleIdx === -1 || contentIdx === -1 || categoryIdx === -1) {
                        showNotification('❌ CSV muss Spalten: title, content, category enthalten');
                        return;
                    }

                    pendingImport = [];
                    for (let i = 1; i < lines.length; i++) {
                        if (!lines[i].trim()) continue;

                        const parts = parseCSVLine(lines[i]);
                        if (parts.length < 3) continue;

                        const title = (parts[titleIdx] || '').replace(/^"|"$/g, '').trim() || '';
                        const content = (parts[contentIdx] || '').replace(/^"|"$/g, '').trim() || '';
                        const category = (parts[categoryIdx] || '').replace(/^"|"$/g, '').trim().toLowerCase() || '';

                        if (!title || !content || !category) continue;
                        if (!['gemini', 'chatgpt', 'general'].includes(category)) continue;
                        if (content.length > 10000) continue;

                        pendingImport.push({ title, content, category });
                    }

                    if (pendingImport.length === 0) {
                        showNotification('❌ Keine gültigen Prompts in der Datei gefunden');
                        return;
                    }

                    showImportPreview();
                } catch (error) {
                    console.error('CSV Parse Error:', error);
                    showNotification('❌ Fehler beim Lesen der Datei');
                }
            };
            reader.readAsText(file);
        }

        function showImportPreview() {
            const preview = document.getElementById('importPreview');
            const previewList = document.getElementById('previewList');
            const count = document.getElementById('importCount');

            count.textContent = pendingImport.length;

            previewList.innerHTML = pendingImport.slice(0, 5).map((p, idx) => `
                <div class="card" style="margin: 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong style="font-size: 14px;">${escapeHtml(p.title)}</strong>
                        <span class="category-badge category-${p.category}">${p.category}</span>
                    </div>
                    <div style="font-size: 12px; color: var(--on-surface-variant); white-space: pre-wrap; max-height: 80px; overflow: hidden;">
                        ${escapeHtml(p.content.substring(0, 100))}${p.content.length > 100 ? '...' : ''}
                    </div>
                </div>
            `).join('');

            preview.style.display = 'block';
        }

        function cancelImport() {
            pendingImport = [];
            document.getElementById('importPreview').style.display = 'none';
            document.getElementById('csvFile').value = '';
            showNotification('⏸️ Import abgebrochen');
        }

        async function importPrompts() {
            if (pendingImport.length === 0) return;

            const btn = event.target;
            btn.disabled = true;
            btn.textContent = '⏳ Importiere...';

            let successCount = 0;
            let errorCount = 0;

            for (const prompt of pendingImport) {
                try {
                    const response = await fetch(API_BASE + 'api/prompts', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(prompt)
                    });

                    if (response.ok) {
                        successCount++;
                    } else {
                        errorCount++;
                    }
                } catch (error) {
                    errorCount++;
                }
            }

            await loadPrompts();
            displayPrompts();
            cancelImport();
            switchTab('view');

            btn.disabled = false;
            btn.textContent = '✅ Importieren';

            showNotification(`✅ ${successCount}/${pendingImport.length} Prompts importiert${errorCount > 0 ? ` (${errorCount} Fehler)` : ''}`);
        }

        function exportAsCSV() {
            if (allPrompts.length === 0) {
                showNotification('⚠️ Keine Prompts zum Exportieren');
                return;
            }

            const header = 'title,content,category\n';
            const rows = allPrompts.map(p => {
                const title = `"${p.title.replace(/"/g, '""')}"`;
                const content = `"${p.content.replace(/"/g, '""')}"`;
                return `${title},${content},${p.category}`;
            }).join('\n');

            const csv = header + rows;
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);

            link.setAttribute('href', url);
            link.setAttribute('download', `promptsave-export-${new Date().toISOString().slice(0, 10)}.csv`);
            link.style.visibility = 'hidden';

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            showNotification(`📤 ${allPrompts.length} Prompts als CSV exportiert!`);
        }

        function exportAsPDF() {
            if (allPrompts.length === 0) {
                showNotification('⚠️ Keine Prompts zum Exportieren');
                return;
            }

            const htmlContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>promptsave Export</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        h1 { color: #1DB679; border-bottom: 3px solid #1DB679; padding-bottom: 10px; }
        .metadata { color: #666; font-size: 12px; margin-bottom: 30px; }
        .prompt { page-break-inside: avoid; margin-bottom: 30px; padding: 15px; border-left: 4px solid #1DB679; background: #f9f9f9; }
        .prompt-title { font-weight: bold; font-size: 16px; margin-bottom: 5px; }
        .prompt-meta { font-size: 12px; color: #666; margin-bottom: 10px; }
        .prompt-content { font-size: 14px; white-space: pre-wrap; word-wrap: break-word; }
        .category { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; margin-right: 8px; }
        .category-gemini { background: rgba(0, 188, 212, 0.2); color: #0096AA; }
        .category-chatgpt { background: rgba(76, 175, 80, 0.2); color: #2E7D32; }
        .category-general { background: rgba(255, 152, 0, 0.2); color: #E65100; }
    </style>
</head>
<body>
    <h1>🔖 realteacher's promptsave</h1>
    <div class="metadata">
        <p><strong>Exportiert:</strong> ${new Date().toLocaleString('de-DE')}</p>
        <p><strong>Anzahl Prompts:</strong> ${allPrompts.length}</p>
    </div>
    
    ${allPrompts.map((p, idx) => {
                const dateStr = parsePromptDate(p.createdAt);
                return `
        <div class="prompt">
            <div class="prompt-title">${idx + 1}. ${escapeHtml(p.title)}</div>
            <div class="prompt-meta">
                <span class="category category-${p.category}">${p.category.toUpperCase()}</span>
                <span>📅 ${dateStr}</span>
            </div>
            <div class="prompt-content">${escapeHtml(p.content)}</div>
        </div>
    `;
            }).join('')}
</body>
</html>
            `;

            const printWindow = window.open('', '_blank');
            printWindow.document.write(htmlContent);
            printWindow.document.close();
            printWindow.focus();

            setTimeout(() => {
                printWindow.print();
            }, 250);

            showNotification(`📄 ${allPrompts.length} Prompts für PDF-Export vorbereitet!`);
        }

        // Load on startup
        window.addEventListener('DOMContentLoaded', () => {
            initializeApp();
            updateExportCount();
        });

        // Update export count after each operation
        const originalLoadPrompts = loadPrompts;
        loadPrompts = async function() {
            await originalLoadPrompts.call(this);
            updateExportCount();
        };
    </script>
</body>
</html>