<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$dbFile = __DIR__ . '/heisser-scheiss.db';

try {
    $db = new PDO('sqlite:' . $dbFile);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $db->exec("CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        content TEXT,
        link TEXT,
        image TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )");
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Datenbankfehler: ' . $e->getMessage()]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$password = $input['password'] ?? '';

// Passwort-Schutz
$correctPassword = 'hotstuff';

if ($password !== $correctPassword) {
    echo json_encode(['success' => false, 'message' => 'Falsches Passwort']);
    exit;
}

try {
    switch ($action) {
        case 'test':
            echo json_encode(['success' => true, 'message' => 'Verbindung OK']);
            break;
            
        case 'getAll':
            $stmt = $db->query("SELECT * FROM items ORDER BY created_at DESC");
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'items' => $items]);
            break;
            
        case 'create':
            $item = $input['item'];
            $now = date('Y-m-d H:i:s');
            
            $stmt = $db->prepare("INSERT INTO items (title, category, content, link, image, created_at, updated_at) 
                                  VALUES (:title, :category, :content, :link, :image, :created_at, :updated_at)");
            
            $stmt->execute([
                ':title' => $item['title'],
                ':category' => $item['category'],
                ':content' => $item['content'] ?? '',
                ':link' => $item['link'] ?? '',
                ':image' => $item['image'] ?? '',
                ':created_at' => $now,
                ':updated_at' => $now
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Eintrag erstellt', 'id' => $db->lastInsertId()]);
            break;
            
        case 'update':
            $item = $input['item'];
            $now = date('Y-m-d H:i:s');
            
            $stmt = $db->prepare("UPDATE items SET 
                                  title = :title, 
                                  category = :category, 
                                  content = :content, 
                                  link = :link, 
                                  image = :image, 
                                  updated_at = :updated_at 
                                  WHERE id = :id");
            
            $stmt->execute([
                ':title' => $item['title'],
                ':category' => $item['category'],
                ':content' => $item['content'] ?? '',
                ':link' => $item['link'] ?? '',
                ':image' => $item['image'] ?? '',
                ':updated_at' => $now,
                ':id' => $item['id']
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Eintrag aktualisiert']);
            break;
            
        case 'delete':
            $id = $input['id'];
            
            $stmt = $db->prepare("DELETE FROM items WHERE id = :id");
            $stmt->execute([':id' => $id]);
            
            echo json_encode(['success' => true, 'message' => 'Eintrag gelöscht']);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Unbekannte Aktion']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Fehler: ' . $e->getMessage()]);
}
